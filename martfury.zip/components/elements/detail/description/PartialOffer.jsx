import React from 'react';

const PartialOffer = () => (
    <p>Sorry no more offers available</p>
);

export default PartialOffer;