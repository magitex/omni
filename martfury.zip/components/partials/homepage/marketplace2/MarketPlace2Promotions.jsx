import React from 'react';

const MarketPlace2Promotions = () => (
    <div className="ps-promotions">
        <div className="container">
            <a className="ps-collection" href="shop-default.html">
                <img src="/static/img/promotions/home-4-1.jpg" alt="martfury" />
            </a>
        </div>
    </div>
);

export default MarketPlace2Promotions;
