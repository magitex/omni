module.exports = {
    baseUrl: 'http://166.62.36.174:8080/OmniKeyzRestAPI',
    dashboardData: '/rs/v1/master/getDashboardDetails',
    auth: '/oauth/token',
};
